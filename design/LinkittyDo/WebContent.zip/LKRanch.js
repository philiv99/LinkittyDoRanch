		var globalMenuSpec;
		var globalLayoutSpec;
		var globalStylesSpec;
		var cssPropertyMap;
		
		var defaultSpeed = 400;
		

		function addCSSRule(/* string */ selector, /* string */ rule) {
			  if (document.styleSheets) {
			    if (!document.styleSheets.length) {
			      var head = document.getElementsByTagName('head')[0];
			      head.appendChild(bc.createEl('style'));
			    }

			    var i = document.styleSheets.length-1;
			    var ss = document.styleSheets[i];

			    var l=0;
			    if (ss.cssRules) {
			      l = ss.cssRules.length;
			    } else if (ss.rules) {
			      // IE
			      l = ss.rules.length;
			    }

			    if (ss.insertRule) {
			      ss.insertRule(selector + ' {' + rule + '}', l);
			    } else if (ss.addRule) {
			      // IE
			      ss.addRule(selector, rule, l);
			    }
			  }
			};

		
		$(document).ready(function() {
				
			startup();
			startupStatus("Starting LKRanch...");
			
			baseurl = 'http://spreadsheets.google.com/tq?key=0AhXLHbmFCZ4cdDVpMEp1VTBCMXVQWGg1VmZMUHc4THc';

			startupStatus("Loading Styles...");
			initGlobalSpecStyles(baseurl+'&sheet=Styles');
			startupStatus("Loading Menus...");
			initGlobalSpecMenu(baseurl+'&sheet=Menus');
			startupStatus("Loading Layout...");
			initGlobalSpecLayout(baseurl+'&sheet=Layout');
			
			window.setTimeout(finishInit, 1000);
		});
		
		function finishInit() {
			for (i=0;i<globalStylesSpec.length;i++) {
				updateStyle(globalStylesSpec[i].classname, globalStylesSpec[i]);
			}
			window.setTimeout(finishStyling, 1000);
		}

		function finishStyling() {
			for (i=0;i<globalMenuSpec.length;i++) 
				initMenuItem(globalMenuSpec[i]);
			for (i=0;i<globalLayoutSpec.length;i++) 
			  	initLayoutItem(globalLayoutSpec[i]);
			startupClose();
			$('body').append('<div class="lkbackground" />');
		}
		
		function startupStatus(msg) {
			$("#startupmsg").html(msg);	
		}
		
		function startupClose() {
			$('#mask, .window').hide();
			$("#dialog").hide();
		}
		
		function startup() {
			
				id = "#startup";
				
				//Get the screen height and width
				var maskHeight = $(document).height();
				var maskWidth = $(window).width();
			
				//Set height and width to mask to fill up the whole screen
				$('#mask').css({'width':maskWidth,'height':maskHeight});
				
				//transition effect		
				$('#mask').fadeIn(300);	
				$('#mask').fadeTo("slow",0.8);	
			
				//Get the window height and width
				var winH = $(window).height();
				var winW = $(window).width();
		              
				//Set the popup window to center
				$("#dialog").css('top',  winH/2-$(id).height()/2);
				$("#dialog").css('left', winW/2-$(id).width()/2);
			
				//transition effect
				$("#dialog").fadeIn(300); 
		}
		

		//------------------------------------------------------
		// Layout styles
		//------------------------------------------------------
		function initGlobalSpecStyles(url) {
			var query = new google.visualization.Query(url);
			query.send(handleQueryResponseStyles);
		}

		function handleQueryResponseStyles(response) {
		  if (response.isError()) {
			alert('Error in Styles query: ' + response.getMessage() + ' ' + response.getDetailedMessage());
			return;
		  }
		
		  var data = response.getDataTable();
		  
		  rowCount = data.getNumberOfRows();
		  colCount =  data.getNumberOfColumns();
		  
		  cssPropertyMap = new Array(colCount);
		  for(var dcol=0; dcol<colCount; dcol++) {
			  if (data.getColumnLabel(dcol) != "") {
				  l = data.getColumnLabel(dcol).split(",");
				  cssPropertyMap[l[0]] = l[1];
			  }
		  }

		  globalStylesSpec = new Array(rowCount);
		  var o; 
		  o = new Object();
		  for (var drow=0; drow<rowCount; drow++) {
			  o = new Object();
			  for(var dcol=0; dcol<colCount; dcol++) {
				  l = data.getColumnLabel(dcol).split(",");
				  o[l[0]] = data.getFormattedValue(drow,dcol);
			  }
			  globalStylesSpec[drow] = o;
		  }
		}
		
		function updateStyle(name, styleSpec) {
			

			for (prop in styleSpec) {
				if (cssPropertyMap[prop] != "classname" && cssPropertyMap[prop] != null) {
					addCSSRule("."+styleSpec.classname,cssPropertyMap[prop]+":"+styleSpec[prop]+";");
				}
			}
			
		}

		
		//------------------------------------------------------
		// Layout init
		//------------------------------------------------------
		function initGlobalSpecLayout(url) {
			var query = new google.visualization.Query(url);
			query.send(handleQueryResponseLayout);
		}

		function handleQueryResponseLayout(response) {
		  if (response.isError()) {
			alert('Error in Layout query: ' + response.getMessage() + ' ' + response.getDetailedMessage());
			return;
		  }
		
		  var data = response.getDataTable();
		  
		  globalLayoutSpec = new Array(data.getNumberOfRows());
		  var o; 
															
		  for (var drow=0; drow<data.getNumberOfRows(); drow++) {
			  o = new Object();
			  o.layoutid = data.getFormattedValue(drow,0);
			  o.divid = data.getFormattedValue(drow,1);
			  o.containerdiv = data.getFormattedValue(drow,2);
			  o.zindex = data.getFormattedValue(drow,3);
			  o.top = data.getFormattedValue(drow,4);
			  o.left = data.getFormattedValue(drow,5);
			  o.height = data.getFormattedValue(drow,6);
			  o.width = data.getFormattedValue(drow,7);
			  o.cssclass = data.getFormattedValue(drow,8);
			  o.content = data.getFormattedValue(drow,9);
			  globalLayoutSpec[drow] = o;
		  }
		 
		}

		function initLayoutItem(spec) {

			// add layout div
			$('body').append('<span class="'+spec.cssclass+'" id="'+spec.divid+'" />');

			var el = $('#'+spec.divid);
			
			el.click(function(){
				//alert("Clicked header");
			});
			
			// save the current kayout id into the layoutid attribute
			el.attr("layoutid",spec.layoutid); 
			
			// set initial display of the layout item
			setLayout(el, spec, defaultSpeed);
		}
		function setLayout(el,spec,speed) {
			el.animate({ 
				top: spec.top,
				left: spec.left,
				width: spec.width,
				height: spec.height,
				'z-index': spec.zindex
			}, speed, function(){ 
				el.html(spec.content);
			   }
			);
		}
		
		
		//------------------------------------------------------
		// Menu init
		//------------------------------------------------------
		function initGlobalSpecMenu(url) {
			var query = new google.visualization.Query(url);
			query.send(handleQueryResponseMenu);
		}

		function handleQueryResponseMenu(response) {
		  if (response.isError()) {
			alert('Error in Menu query: ' + response.getMessage() + ' ' + response.getDetailedMessage());
			return;
		  }
		
		  var data = response.getDataTable();
		  
		  globalMenuSpec = new Array(data.getNumberOfRows());
		  var o; // temp menuSpec object
		  var s; // temp menus state object
		  
		  for (var drow=0; drow<data.getNumberOfRows(); drow++) {
			  o = new Object();
			  o.gspecid = data.getFormattedValue(drow,0);
			  o.id = data.getFormattedValue(drow,1);
			  o.initstate = data.getFormattedValue(drow,2);
			  o.resetstate = data.getFormattedValue(drow,3);
			  o.zindex = data.getFormattedValue(drow,4);
			  states = [];
			  for (var st=0; st<data.getFormattedValue(drow,5); st++) {
				  b = 6+(8*st);
				  states[st] = {status:    data.getFormattedValue(drow,b),	
							 top:       data.getFormattedValue(drow,b+1),
							 left:      data.getFormattedValue(drow,b+2),
							 height:	data.getFormattedValue(drow,b+3),
							 width:     data.getFormattedValue(drow,b+4),
							 cssclass:  data.getFormattedValue(drow,b+5),
							 innerhtml: data.getFormattedValue(drow,b+6),
							 clickstate:data.getFormattedValue(drow,b+7)
			                 };
				  ;
			  }
			  o.states = states;
			  globalMenuSpec[drow] = o;
		  }
		 
		}
		
		function initMenuItem(menuSpec) {

			// add menu div
			$('body').append('<span class="'+menuSpec.states[menuSpec.initstate].cssclass+'" id="'+menuSpec.id+'" />');

			var el = $('#'+menuSpec.id);
			
			el.click(function(){
				curState = $(this).attr("state");
				if (menuSpec.states[curState].status!="active") {
					menuSpec = globalMenuSpec[$(this).attr("gspecid")];
					clickState = menuSpec.states[curState].clickstate;
					resetMenus();
					setMenu($(this),clickState, menuSpec, defaultSpeed);
				}
			});
			
			// save the current menu id into the gspecid attribute
			el.attr("gspecid",menuSpec.gspecid); 
			
			// set initial display of the new menu item
			setMenu(el,menuSpec.initstate,menuSpec,defaultSpeed);
		}

		function resetMenus() {
			  for (i=0;i<globalMenuSpec.length;i++) {
				  var menuSpec = globalMenuSpec[i];
				  var el = $('#'+menuSpec.id);
				  setMenu(el,menuSpec.resetstate,menuSpec,defaultSpeed);
			  }
		}
		function setMenu(el,iSt,menuSpec,speed) {
			//changeCSSClass(el,menuSpec.states[iSt].cssclass);
			el.animate({ 
				top: menuSpec.states[iSt].top,
				left: menuSpec.states[iSt].left,
				height: menuSpec.states[iSt].height,
				width: menuSpec.states[iSt].width,
				'z-index': menuSpec.states[iSt].zindex
			}, speed, function(){ //alert("Complete");
			   }
			);
			el.html(menuSpec.states[iSt].innerhtml);
			el.attr("state",iSt);
			changeCSSClass(el,menuSpec.states[iSt].cssclass);
		}
		
		//------------------------------------------------------
		// utility stuff
		//------------------------------------------------------
		function changeCSSClass(el, classname) {
			//el.removeClass(el.attr("class"));
			//el.addClass(classname);
		}